const path = require('path');
const ExtractTextPlugin = require('extract-text-webpack-plugin'); //Extract CSS
const UglifyJsPlugin = require('uglifyjs-webpack-plugin'); // Minify JS

module.exports = {
    mode: "production", // "production" | "development" | "none"
    entry: ['./src/import-module.js'],
    output: {
        path: path.resolve(__dirname, 'dist'),
        publicPath:'./dist/',
        filename: 'js/app.js',
    },
    module: {
        rules: [{
            test:/\.(s*)css$/, 
            use: ExtractTextPlugin.extract({  //Seperate files [css]
                fallback:'style-loader',
                use:['css-loader','sass-loader'],
                publicPath: '../' //custom path for css public path
            })
        }, {
        test: /\.(png|jpg|gif)$/,
        use: [
          {
            loader: 'file-loader',
            options: {
                outputPath: 'images/'//custom path for images
            }
          }
        ]
      }]
    },
    plugins: [
        new ExtractTextPlugin({filename:'css/app.bundle.css'})
    ],
    optimization: {
        minimizer: [
          new UglifyJsPlugin({ //minify JS
            test: /\.js($|\?)/i
        })]
    }
};