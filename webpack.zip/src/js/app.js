// custom script goes here
 import "./vendor/custom";