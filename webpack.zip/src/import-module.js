/*
* STYLESHEET
* require [css, scss, sass] modules | import and Es6 method
*/
import "../node_modules/bootstrap/scss/bootstrap.scss";
import "./scss/main.scss";
// require('./scss/main.scss');

/*
* JS
* require js modules | import and Es6 method
*/
import "jquery";
import 'bootstrap';
import "./js/app";